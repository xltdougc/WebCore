﻿namespace WebCore.Controllers
{
    internal class HttpContextWrapper
    {
    }
}