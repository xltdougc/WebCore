﻿namespace WebCore.Controllers
{
    internal class RemoteEndpointMessageProperty
    {
    }
}